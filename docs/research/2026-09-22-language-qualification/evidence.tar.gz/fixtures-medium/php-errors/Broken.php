<?php function broken( {
