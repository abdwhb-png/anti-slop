<?php namespace Fixture; final class Child extends MissingParent {}
