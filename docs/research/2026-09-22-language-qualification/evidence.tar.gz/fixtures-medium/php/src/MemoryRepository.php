<?php
namespace Fixture;
final class MemoryRepository implements Repository {
    public function load(OrderId $id): string { return $id->value; }
}
