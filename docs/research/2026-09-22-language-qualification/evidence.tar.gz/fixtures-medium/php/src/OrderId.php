<?php
namespace Fixture;
final readonly class OrderId {
    public function __construct(public string $value) {
        if ($value === '') { throw new \InvalidArgumentException('empty'); }
    }
}
