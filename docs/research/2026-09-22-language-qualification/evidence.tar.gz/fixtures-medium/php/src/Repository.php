<?php
namespace Fixture;
interface Repository { public function load(OrderId $id): string; }
