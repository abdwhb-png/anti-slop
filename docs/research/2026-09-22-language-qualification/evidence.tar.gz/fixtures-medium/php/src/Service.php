<?php
namespace Fixture;
function serve(Repository $repository, string $raw): string {
    if ($raw === '') { throw new \InvalidArgumentException('empty'); }
    $id = new OrderId($raw);
    return $repository->load($id);
}
function dynamic_call(object $service, string $method): mixed {
    return $service->$method();
}
