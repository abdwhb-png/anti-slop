fn main() { std::fs::write(std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("qualification-build-script-ran"), b"executed").unwrap(); println!("cargo:rustc-cfg=from_build"); }
