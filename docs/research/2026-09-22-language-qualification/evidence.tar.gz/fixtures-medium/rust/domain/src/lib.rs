pub struct OrderId(pub u64);
pub trait Repository { fn load(&self, id: &OrderId) -> u64; }
pub struct MemoryRepository;
impl Repository for MemoryRepository { fn load(&self, id: &OrderId) -> u64 { id.0 } }
#[cfg(feature = "extra")]
pub fn feature_only() -> u64 { 99 }
macro_rules! make_getter { ($name:ident) => { pub fn $name() -> u64 { 7 } }; }
make_getter!(generated);
