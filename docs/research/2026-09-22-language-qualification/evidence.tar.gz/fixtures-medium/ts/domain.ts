// Reject empty identifiers at the boundary.
export type OrderId = string & { readonly __brand: "OrderId" };
export function normalize(raw: string): OrderId {
  if (raw.length === 0) throw new Error("empty");
  return raw as OrderId;
}
