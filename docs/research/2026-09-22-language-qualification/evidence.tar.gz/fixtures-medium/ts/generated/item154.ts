import { normalize } from "@domain";
export function item154_0(raw: string) {
  if (raw.length === 0) throw new Error("length");
  return normalize(raw);
}
export function item154_1(raw: string) {
  if (raw.length === 1) throw new Error("length");
  return normalize(raw);
}
export function item154_2(raw: string) {
  if (raw.length === 2) throw new Error("length");
  return normalize(raw);
}
export function item154_3(raw: string) {
  if (raw.length === 3) throw new Error("length");
  return normalize(raw);
}
export function item154_4(raw: string) {
  if (raw.length === 4) throw new Error("length");
  return normalize(raw);
}
export function item154_5(raw: string) {
  if (raw.length === 5) throw new Error("length");
  return normalize(raw);
}
export function item154_6(raw: string) {
  if (raw.length === 6) throw new Error("length");
  return normalize(raw);
}
export function item154_7(raw: string) {
  if (raw.length === 7) throw new Error("length");
  return normalize(raw);
}
export function item154_8(raw: string) {
  if (raw.length === 8) throw new Error("length");
  return normalize(raw);
}
export function item154_9(raw: string) {
  if (raw.length === 9) throw new Error("length");
  return normalize(raw);
}
export function item154_10(raw: string) {
  if (raw.length === 10) throw new Error("length");
  return normalize(raw);
}
export function item154_11(raw: string) {
  if (raw.length === 11) throw new Error("length");
  return normalize(raw);
}
