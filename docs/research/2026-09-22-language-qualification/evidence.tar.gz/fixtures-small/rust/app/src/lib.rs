use qualification_domain::{OrderId, Repository, MemoryRepository, generated};
pub fn serve() -> u64 {
    let id = OrderId(42);
    MemoryRepository.load(&id) + generated()
}
