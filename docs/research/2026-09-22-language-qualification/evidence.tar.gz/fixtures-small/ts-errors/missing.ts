import { absent } from "./does-not-exist"; export const value = absent(42);
