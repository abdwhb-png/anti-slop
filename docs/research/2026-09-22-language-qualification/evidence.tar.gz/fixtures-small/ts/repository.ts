import type { OrderId } from "@domain";
export interface Repository { load(id: OrderId): string; }
export class MemoryRepository implements Repository {
  load(id: OrderId): string { return id; }
}
