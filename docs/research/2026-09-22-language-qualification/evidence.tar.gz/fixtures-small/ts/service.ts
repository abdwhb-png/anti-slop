import { normalize as parseId } from "@domain";
import { MemoryRepository } from "./repository";
export const result = parseId("42");
export const answer = new MemoryRepository().load(result);
export async function dynamicModule(path: string) { return import(path); }
