export const twice = (x: number) => x * 2;
