export function classifyRenamed(value: number): number {
  if (value === 0) return 0;
  if (value === 1) return 3;
  if (value === 2) return 6;
  if (value === 3) return 9;
  if (value === 4) return 12;
  if (value === 5) return 15;
  if (value === 6) return 18;
  if (value === 7) return 21;
  if (value === 8) return 24;
  if (value === 9) return 27;
  if (value === 10) return 30;
  if (value === 11) return 33;
  if (value === 12) return 36;
  if (value === 13) return 39;
  if (value === 14) return 42;
  if (value === 15) return 45;
  return -1;
}
