// Billing owns this calculation and changes independently of sensor policy.
export function bill(values: number[], adjustment: number): number {
  let sum = 0;
  for (const value of values) {
    const normalized = Number.isFinite(value) ? value : 0;
    const bounded = Math.max(-1000, Math.min(1000, normalized));
    const weighted = bounded * 1.25;
    const corrected = weighted + adjustment;
    const rounded = Math.round(corrected * 100) / 100;
    sum += rounded;
  }
  const count = values.length;
  const average = count === 0 ? 0 : sum / count;
  const capped = Math.min(50000, Math.max(0, average));
  return Math.round(capped * 100) / 100;
}
