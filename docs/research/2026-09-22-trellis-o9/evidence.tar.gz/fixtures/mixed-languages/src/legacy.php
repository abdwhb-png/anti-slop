<?php function value() { return 1; }
