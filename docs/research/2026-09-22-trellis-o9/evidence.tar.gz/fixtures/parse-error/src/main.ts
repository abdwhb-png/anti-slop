export function broken( { return 42;
