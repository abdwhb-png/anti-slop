const amount = (x: number) => x * 2;
const service = (x: number) => amount(x);
const facade = (x: number) => service(x);
export const endpoint = (x: number) => facade(x);
