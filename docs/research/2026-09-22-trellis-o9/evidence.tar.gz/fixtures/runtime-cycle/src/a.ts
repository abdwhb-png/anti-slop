import { b } from './b';
export function a(x: number): number { return x ? b(x - 1) : 0; }
