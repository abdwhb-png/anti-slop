import { a } from './a';
export function b(x: number): number { return x ? a(x - 1) : 0; }
