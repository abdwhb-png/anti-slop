export const batchCanOrder = (total: number) => total >= 75 && total <= 5000;
