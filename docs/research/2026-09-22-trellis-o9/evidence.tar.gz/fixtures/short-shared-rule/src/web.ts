export const webCanOrder = (total: number) => total >= 75 && total <= 5000;
