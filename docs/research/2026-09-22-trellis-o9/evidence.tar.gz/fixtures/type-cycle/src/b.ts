import type { A } from './a';
export interface B { peer?: A; }
